import { Component, OnInit } from '@angular/core';
import { GlobalService } from '../global.service';
import Swal from 'sweetalert2';


interface Bookings {
  user: any;
  sport: any;
  members: any;
  bookingTime: any;
}

interface Sport {
  id: number;
  name: string;
}

@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.css']
})
export class BookingComponent implements OnInit {
  availableSports: Sport[] = [];
  user: any;
  sport: any;
  members: any;
  bookingTime: any;
  bookingStatus: string = '';
  prasanth: string = '';

  constructor(private ms: GlobalService) {}

  ngOnInit() {
    this.fetchAvailableSports();
  }

  fetchAvailableSports() {
    this.ms.fetchSports().subscribe(
      (sports: Sport[]) => {
        this.availableSports = sports;
      },
      (error) => {
        console.error('Error fetching sports:', error);
      }
    );
  }

  openForm(data: Bookings | null = null) {
    this.user = data?.user;
    this.sport = data?.sport;
    this.members = data?.members;
    this.bookingTime = data?.bookingTime;
  }

  saveBooking() {
    let body = {
      user: { id: localStorage.getItem('id') },
      sport: { id: this.sport },
      members: this.members,
      bookingTime: this.bookingTime
    };
  
    this.ms.postBooking(body).subscribe(
      (response: any) => {
        this.sport = response.sport;
        this.members = response.members;
        this.bookingTime = response.bookingTime;
        this.bookingStatus = 'Booked successfully!';
  
        Swal.fire({
          title: 'Booking Successful!',
          text: 'Your booking has been made.',
          icon: 'success',
          confirmButtonText: 'OK'
        });
      },
      (error) => {
        Swal.fire({
          title: 'Booking Failed',
          text: 'The selected sport is already booked on this date.',
          icon: 'error',
          confirmButtonText: 'OK'
        });
      }
    );
  }
  

  resetForm() {
    this.user = '';
    this.sport = '';
    this.members = '';
    this.bookingTime = '';
    this.bookingStatus = '';
  }
}
