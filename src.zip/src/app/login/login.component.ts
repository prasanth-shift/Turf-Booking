import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthServiceService } from '../auth-service.service';
import { GlobalService } from '../global.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  c: string = "";
  userId: any;
  email: any;
  password: any;

  constructor(
    private auth: AuthServiceService,
    private ms: GlobalService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.clearLocalStorage();
  }

  clearLocalStorage() {
    if (typeof localStorage !== 'undefined') {
      localStorage.clear();
    }
  }

  submitForm(_t11: any) {
    console.log(_t11);
  }

  login() {
    if (this.email === "admin@gmail.com" && this.password === "admin@123") {
      this.setLocalStorage("role", "admin");
      this.router.navigate(["/admin"]);
    } else {
      this.ms.UserExists({ "email": this.email, "password": this.password }).subscribe(
        (data: any) => {
          if (data !== null) {
            this.userId = data.id;
            this.setLocalStorage("id", data.id);
            this.setLocalStorage("role", "user");
            this.router.navigate(["/home"]);
          } else {
            Swal.fire({
              icon: 'error',
              title: 'invalid credentials',
              // showConfirmButton: false,
              timer: 3000
            });
          }
        }
      );
    }
  }

  setLocalStorage(key: string, value: any) {
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem(key, value);
    }
  }
}
