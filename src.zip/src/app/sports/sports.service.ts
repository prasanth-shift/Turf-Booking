import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
 
@Injectable({
  providedIn: 'root'
})
export class SportService {
private baseUrl = 'http://localhost:8080/sports/get';
 
  constructor(private http: HttpClient) { }
 
  getSports(){
    return this.http.get(this.baseUrl);
  }
 
}