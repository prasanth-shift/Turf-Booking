package main.sports.imp.controller;

import org.springframework.web.bind.annotation.*;

import main.sports.imp.model.Payment;
import main.sports.imp.service.PaymentService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/payments")
public class PaymentController {
    private final PaymentService paymentService;

    public PaymentController(PaymentService paymentService) {
        this.paymentService = paymentService;
    }

    @DeleteMapping("/{paymentId}")
    public void deletePaymentById(@PathVariable Long paymentId) {
        paymentService.deletePaymentById(paymentId);
    }

    @PostMapping("/")
    public Payment savePayment(@RequestBody Payment payment) {
        return paymentService.savePayment(payment);
    }

    @GetMapping("/{paymentId}")
    public Optional<Payment> getPaymentById(@PathVariable Long paymentId) {
        return paymentService.getPaymentById(paymentId);
    }
    @GetMapping("/")
    public List<Payment> getPayments() {
      List<Payment> payments = paymentService.getAllPayments();
      return payments;
    }
}

 