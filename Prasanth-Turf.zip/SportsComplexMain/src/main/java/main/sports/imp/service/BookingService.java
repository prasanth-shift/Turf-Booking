package main.sports.imp.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import main.sports.imp.DTO.BookingsDTO;
import main.sports.imp.exception.BookingException;
import main.sports.imp.model.Booking;
import main.sports.imp.model.Sports;
import main.sports.imp.repository.BookingRepository;

@Service
public class BookingService {

    private BookingRepository bookingRepository;

    private SportsService ssl;

    @Autowired
    public BookingService(BookingRepository bookingRepository, SportsService ssl) {
        this.bookingRepository = bookingRepository;
        this.ssl = ssl;
    }

    public Booking saveBooking(Booking book) {
        Sports sport = book.getSport();
        if (sport != null) {
            Long l = sport.getId();
            Sports sport1 = ssl.getSportById(l);
            book.setAmount(sport1.getPrice() * book.getMembers());
            if (bookingRepository.existsByBookingTimeAndSport(book.getBookingTime(), book.getSport())) {
                throw new BookingException("The selected sport " + sport1.getName() + " on this date "
                        + book.getBookingTime() + " is already booked.");
            }
            return bookingRepository.save(book);
        }
        return bookingRepository.save(book);
    }

    public List<BookingsDTO> getAllBookings() {
        List<Booking> bookList = bookingRepository.findAll();
        List<BookingsDTO> info = new ArrayList<>();
        for (Booking b : bookList) {
            BookingsDTO bookObj = new BookingsDTO();

            bookObj.setBookId(b.getId());
            bookObj.setSportId(b.getSport().getId());
            bookObj.setName(b.getSport().getName());

            bookObj.setUserId(b.getUser().getId());
            bookObj.setUserName(b.getUser().getUserName());
            bookObj.setMembers(b.getMembers());
            bookObj.setBookingTime(b.getBookingTime());

            bookObj.setAmount(b.getAmount());
            info.add(bookObj);
        }
        return info;
    }

    public BookingsDTO getBookingById(Long id) {
        Booking b = bookingRepository.findById(id).orElse(null);
        BookingsDTO bookObj = new BookingsDTO();
        bookObj.setSportId(b.getSport().getId());
        bookObj.setName(b.getSport().getName());
        bookObj.setBookId(b.getId());
        bookObj.setUserId(b.getUser().getId());
        bookObj.setUserName(b.getUser().getUserName());
        bookObj.setMembers(b.getMembers());
        bookObj.setBookingTime(b.getBookingTime());

        bookObj.setAmount(b.getAmount());
        return bookObj;
    }

    public void deleteBooking(Long id) {
        bookingRepository.deleteById(id);
    }

    public Booking updateBooking(long id, Booking book) {
        Booking existingBooking = bookingRepository.findById(id).orElse(null);
        if (existingBooking != null) {
            existingBooking.setMembers(book.getMembers());
            existingBooking.setBookingTime(book.getBookingTime());
            existingBooking.setAmount(existingBooking.getSport().getPrice() * book.getMembers());
            return bookingRepository.save(existingBooking);
        }
        return null;
    }



}