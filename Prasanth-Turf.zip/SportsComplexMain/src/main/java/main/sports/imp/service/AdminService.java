package main.sports.imp.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import main.sports.imp.model.Booking;
import main.sports.imp.repository.BookingRepository;
 
@Service
public class AdminService {
 
    private final BookingRepository BookingRepository;
 
    @Autowired
    public AdminService(BookingRepository BookingRepository) {
        this.BookingRepository = BookingRepository;
    }
 
    public Map<String, Integer> calculateSportBookingCounts() {
        List<Booking> selections = BookingRepository.findAll();
        Map<String, Integer> sportBookingCounts = new HashMap<>();
        for (Booking selection : selections) {
        	String sportName = selection.getSport().getName();
            if (sportBookingCounts.containsKey(sportName)) {
                int currentCount = sportBookingCounts.get(sportName);
                sportBookingCounts.put(sportName, currentCount + 1);
            } else {
                sportBookingCounts.put(sportName, 1);
            }
        }
        return sportBookingCounts;
    }
 
    public Map<String, Integer> calculateUserBookingCounts() {
        List<Booking> selections = BookingRepository.findAll();
        Map<String, Integer> userBookingCounts = new HashMap<>();
        for (Booking booking : selections) {
            String uName = booking.getUser().getUserName();
            if(userBookingCounts.containsKey(uName)) {
            	int currentCount = userBookingCounts.get(uName);
            	userBookingCounts.put(uName, currentCount+1);
            }else {
            	userBookingCounts.put(uName, 1);
            }
        }
        return userBookingCounts;
    }
}