
package main.sports.imp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import main.sports.imp.model.Booking;
import main.sports.imp.model.Sports;

@Repository
public interface BookingRepository extends JpaRepository<Booking, Long> {
    boolean existsByBookingTimeAndSport(String bookingTime, Sports sport);
}
