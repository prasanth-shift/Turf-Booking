package main.sports.imp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ImpApplication {

	public static void main(String[] args) {
		SpringApplication.run(ImpApplication.class, args);
	}

}
