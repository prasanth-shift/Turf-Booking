package main.sports.imp.service;

import java.time.LocalDate;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import main.sports.imp.model.Review;

import main.sports.imp.repository.ReviewRepository;

@Service
public class ReviewService {

	
	private ReviewRepository reviewRepository;
    
	@Autowired
	public ReviewService(ReviewRepository reviewRepository) {
		this.reviewRepository = reviewRepository;
	}

	public Review createReview(Review review) {
		review.setDate(LocalDate.now());
		return reviewRepository.save(review);
	}

	public Review getReviewById(Long id) {
		return reviewRepository.findById(id).orElse(null);
	}

	public List<Review> getAllReview() {
		List<Review> reviews = reviewRepository.findAll();
		return reviews;
	}

	public Review updateReview(Long id, Review updatedReview) {
		Review existingReview = reviewRepository.findById(id).orElse(null);
		if (existingReview != null) {
			existingReview.setRating(updatedReview.getRating());
			existingReview.setComments(updatedReview.getComments());
			return reviewRepository.save(existingReview);
		}
		return null;
	}

	public void deleteReview(Long id) {
		reviewRepository.deleteById(id);
	}

}