package main.sports.imp.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "sport")
public class Sports {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "sport_id")
	private Long id;

	@Column(name = "sport_name")
	private String name;

	@Column(name = "price")
	private Integer price;

	@OneToMany(mappedBy = "sport", cascade = CascadeType.ALL)
	@JsonIgnore
	private List<Booking> bookings;

	public Sports() {

	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getPrice() {
		return price;
	}

	public void setPrice(Integer price) {
		this.price = price;
	}

	public List<Booking> getBookings() {
		return bookings;
	}

	public void ListBookings(List<Booking> bookings) {
		this.bookings = bookings;
	}

}