package main.sports.imp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import main.sports.imp.model.Sports;
import main.sports.imp.service.SportsService;

import java.util.List;
 
@RestController
@RequestMapping("/sports")
public class SportsController {
    private SportsService sportService;
 
    @Autowired
    public SportsController(SportsService sportService) {
        this.sportService = sportService;
    }
 
    @CrossOrigin
    @PostMapping("/")
    public ResponseEntity<Sports> createSport(@RequestBody Sports sport) {
        Sports newSport = sportService.createSport(sport);
        return ResponseEntity.status(HttpStatus.CREATED).body(newSport);
    }
    
    @CrossOrigin
    @GetMapping("/get/{id}")
    public ResponseEntity<Sports> getSportById(@PathVariable Long id) {
        Sports sport = sportService.getSportById(id);
        if (sport != null) {
            return ResponseEntity.ok(sport);
        }
        return ResponseEntity.notFound().build();
    }
   
    @CrossOrigin(origins="http://localhost:4200/")
    @GetMapping("/get")
    public ResponseEntity<List<Sports>> getAllSports() {
        List<Sports> sports = sportService.getAllSports();
        return ResponseEntity.ok(sports);
    }
    
    @CrossOrigin
    @PutMapping("/put/{id}")
    public ResponseEntity<Sports> updateSport(@PathVariable Long id, @RequestBody Sports updatedSport) {
        Sports sport = sportService.updateSport(id, updatedSport);
        if (sport != null) {
            return ResponseEntity.ok(sport);
        }
        return ResponseEntity.notFound().build();
    }
 
    
    @CrossOrigin
    @DeleteMapping("/d/{id}")
    public ResponseEntity<Void> deleteSport(@PathVariable Long id) {
        sportService.deleteSport(id);
        return ResponseEntity.noContent().build();
    }
}
