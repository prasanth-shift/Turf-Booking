package main.sports.imp.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import main.sports.imp.model.ContactUs;

import main.sports.imp.repository.ContactUsRepository;
import main.sports.imp.repository.SportsRepository;

@Service
public class ContactUsService {

	private ContactUsRepository contactUsRepository;
		
		@Autowired
		public ContactUsService(ContactUsRepository contactUsRepository) {
			this.contactUsRepository = contactUsRepository;
		}

		public ContactUs createContact(ContactUs cu) {
			return contactUsRepository.save(cu);
		}
}