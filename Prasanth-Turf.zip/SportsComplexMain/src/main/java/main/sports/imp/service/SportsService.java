package main.sports.imp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import main.sports.imp.model.Sports;
import main.sports.imp.repository.SportsRepository;

@Service
public class SportsService {
	
	private SportsRepository sportRepository;
	
	@Autowired
	public SportsService(SportsRepository sportRepository) {
		this.sportRepository = sportRepository;
	}

	public Sports createSport(Sports sport) {
		return sportRepository.save(sport);
	}

	public Sports getSportById(Long id) {
		return sportRepository.findById(id).orElse(null);
	}

	public List<Sports> getAllSports() {
		return sportRepository.findAll();
	}

	public Sports updateSport(Long id, Sports updatedSport) {
		Sports existingSport = sportRepository.findById(id).orElse(null);
		if (existingSport != null) {
			existingSport.setName(updatedSport.getName());
			existingSport.setPrice(updatedSport.getPrice());
			return sportRepository.save(existingSport);
		}
		return null;
	}

	public void deleteSport(Long id) {
		sportRepository.deleteById(id);
	}
}