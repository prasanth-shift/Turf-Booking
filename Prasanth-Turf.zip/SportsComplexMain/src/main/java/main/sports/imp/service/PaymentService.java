package main.sports.imp.service;

import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import main.sports.imp.model.Payment;
import main.sports.imp.repository.PaymentRepository;

@Service
public class PaymentService {
    
	private PaymentRepository paymentRepository;
    
    @Autowired
    public PaymentService(PaymentRepository paymentRepository) {
        this.paymentRepository = paymentRepository;
    }
    
    public void deletePaymentById(Long paymentId) {
        paymentRepository.deleteById(paymentId);
    }
    
    public Payment savePayment(Payment payment) {
    	payment.setPaymentTime(LocalTime.now());
    	return paymentRepository.save(payment);
        
    }

    public Optional<Payment> getPaymentById(Long paymentId) {
        return paymentRepository.findById(paymentId);
    }
    public List<Payment> getAllPayments() {
        return paymentRepository.findAll();
    }
 
}
