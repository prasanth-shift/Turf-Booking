package main.sports.imp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

import main.sports.imp.model.ContactUs;



@Repository
public interface ContactUsRepository extends JpaRepository<ContactUs, Long> {

}
