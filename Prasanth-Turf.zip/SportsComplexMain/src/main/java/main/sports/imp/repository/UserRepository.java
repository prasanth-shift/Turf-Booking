package main.sports.imp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import main.sports.imp.model.User;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
	
    @Query(value="select * from user where email=:email and password=:password",nativeQuery=true)
	User findUserByCred(String email,String password);
	
}
