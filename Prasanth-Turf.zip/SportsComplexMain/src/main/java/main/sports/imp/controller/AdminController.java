package main.sports.imp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import main.sports.imp.service.AdminService;

import java.util.Map;
 
@RestController
@RequestMapping("/admin")
public class AdminController {
 
    private final AdminService adminService;
 
    @Autowired
    public AdminController(AdminService adminService) {
        this.adminService = adminService;
    }
    @CrossOrigin
    @GetMapping("/scount")
    public ResponseEntity<Map<String, Integer>> getSportBookingCounts() {
        Map<String, Integer> sportBookingCounts = adminService.calculateSportBookingCounts();
        return ResponseEntity.ok(sportBookingCounts);
    }
 
    @GetMapping("/ucount")
    public ResponseEntity<Map<String, Integer>> getUserBookingCounts() {
        Map<String, Integer> userBookingCounts = adminService.calculateUserBookingCounts();
        return ResponseEntity.ok(userBookingCounts);
    }
}
