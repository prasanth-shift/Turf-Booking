package main.sports.imp;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.test.context.SpringBootTest;

import main.sports.imp.service.UserService;

@SpringBootTest
class UserTest {
	
	@Autowired
	UserService us;

	@Test
	void usersPresentTest() {
		assertNotEquals(0,us.getAllUsers().size());
	}
	@Test
	void userPresentTest() {
		assertNotNull(us.getUserById(1l));
	}
	@Test
	void totalUsersPresentTest() {
		assertEquals(1,us.getAllUsers().size());
	}

}
